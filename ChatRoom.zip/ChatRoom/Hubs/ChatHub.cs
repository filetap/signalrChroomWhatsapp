﻿using ChatRoom.Models;
using ChatRoom.Services.ContactService;
using ChatRoom.Services.MessagePaaswordService;
using ChatRoom.Services.MessageService;
using ChatRoom.Services.PersonService;
using ChatRoom.Services.UserSeenService;
using ChatRoom.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using MongoDB.Bson;
using System.Diagnostics.SymbolStore;
using System.Reflection;
using System.Runtime.Intrinsics.X86;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace ChatRoom.Hubs
{
	public class ChatHub : Hub
	{

		private readonly IPersonService personService;
		private readonly IMessageService messageService;
		private readonly IContactService contactService;
		private readonly IUserSeenService userSeenService;
		private IMessagePaaswordService messagePaaswordService;
		public ChatHub(IPersonService personService, IMessageService messageService,
			IContactService contactService, IUserSeenService userSeenService,
			IMessagePaaswordService messagePaaswordService


			)
		{
			this.personService = personService;
			this.messageService = messageService;
			this.contactService = contactService;
			this.userSeenService = userSeenService;
			this.messagePaaswordService = messagePaaswordService;

		}
		private static List<KeyValuePair<string, string>> NtoIdMappingTable = new List<KeyValuePair<string, string>>();

		public override async Task OnConnectedAsync()
		{
			await base.OnConnectedAsync();

			var username = UserNameCurrentUser();
			//hub user connection id

			var userId = Context.UserIdentifier;


			//store the userid to the list.  
			if (NtoIdMappingTable.Where(x => x.Key == userId).Count() < 1)
			{
				NtoIdMappingTable.Add(new KeyValuePair<string, string>(userId, username));
			}


			var _u = await personService.GetByUserName(username);
			var messages = await messageService.LsitMessage(_u.Id, MessageStatus.read, false);
			if (messages.Count() > 0)
			{
				messages.ForEach(x => x.MessageStatus = MessageStatus.delivered);
			}

			await messageService.UpdateAsync(messages);


			foreach (var item in NtoIdMappingTable.Where(x => x.Key != userId))
			{
				// string username = GetUserId(item.Key);
				//Console.WriteLine("On connected  username : " + item.Value);
				//  await ListContact(item.Value);


			}

			await base.OnConnectedAsync();
		}

		public override async Task OnDisconnectedAsync(Exception? exception)
		{
			var username = Context.User.Identity.Name;
			//hub user connection id

			var userId = Context.UserIdentifier;
			if (NtoIdMappingTable.Where(x => x.Key == userId).Count() > 1)
			{
				NtoIdMappingTable.Remove(new KeyValuePair<string, string>(userId, username));
			}

			foreach (var item in NtoIdMappingTable.Where(x => x.Key != userId))
			{
				// string username = GetUserId(item.Key);
				//Console.WriteLine("On Disconnected  username : " + item.Value);
				//  await ListContact(item.Value);


			}
			await base.OnDisconnectedAsync(exception);


		}
		private string GetUserId(string receiver)
		{

			var temp = NtoIdMappingTable.Where(x => x.Value == receiver);
			if (temp.Count() > 0)
			{
				// Console.WriteLine($"key : {temp.FirstOrDefault().Key} value : {temp.FirstOrDefault().Value}");
				return temp.FirstOrDefault().Key;
			}
			//  Console.WriteLine("empty ... ");
			return string.Empty;

		}




		public async Task sendMessage(Guid reciverId, string message)
		{
			//Get details of the recipient of the message
			Person _u = await personService.GetAsync(reciverId);
			if (_u != null)
			{
				var Sender = await GetUser();
				//Get the details of the user who sent the message
				string RECIVER = _u != null ? GetUserId(_u.UserName) : string.Empty;
				var messageId = Guid.NewGuid();
				DateTime time = DateTime.Now;
				//getting encrypted text message
			var messageTextEncript = await messagePaaswordService.Encript(
				new MessageEncriptViewModel()
				{ body = message, recvId = _u.Id, sender = Sender.Id, Time = time });
				var _message = new Message()
				{
					Id = messageId,
					MessageType = MessageType.Message,
					ReceiverUserName = _u.UserName,
					SenderUserName = Sender.UserName,
					Text = messageTextEncript,
					Time = time,
					MessageStatus = RECIVER != string.Empty ? MessageStatus.delivered : MessageStatus.send,
					ReceiverId = _u.Id,
					SenderId = Sender.Id,
				};

				await messageService.CreateAsync(_message);
				 MessagDecript? messagDecript =  await messagePaaswordService.Dcript(await messageService.GetAsync(messageId));

				if (RECIVER != string.Empty)
				{
					await newContact(RECIVER, _u.Id);
					await Clients.User(RECIVER).SendAsync("ReceiveMessage", messagDecript);
					//await Clients.User(GetUserId(Sender.UserName)).SendAsync("ReceiveMessage", messagDecript);
					 await Clients.User(RECIVER).SendAsync("CheckOpenChatPrivateUser", messagDecript);
				}
				else
				{ await Clients.User(Sender.Id.ToString()).SendAsync("ReceiveMessage", messagDecript); }
				var reciverContact = await contactService.GeSingleAsync(_u.Id, Sender.Id);
				if (reciverContact == null)
				{ await contactService.CreateAsync(new Contact() { Owner = _u.Id, Subscribers = Sender.Id, IsSubscribers = false }); }
			}
		}
		public async Task CheckOpenChatPrivateUser(MessagDecript message, bool status)
		{
			message.MessageStatus = status == true ? MessageStatus.read : message.MessageStatus;
			 var encMessage = await messageService.GetAsync(message.Id);
			encMessage.MessageStatus = message.MessageStatus;
			
 			await messageService.UpdateAsync(message.Id, encMessage);
			if (message.MessageStatus == MessageStatus.delivered)
			{ await ListContact(message.ReceiverUserName); }
			// MessagDecript? messagDecript = await messagePaaswordService.Dcript(message);

			await Clients.User(GetUserId(message.SenderUserName)).SendAsync("ReceiveMessage", message );

		}
		private async Task newContact(string reciver, Guid resId)
		{
			var contact = await contactService.GetListAsync(resId);
			// var ConatctInMessage = await messageService.LsitMessage(_u.Id);
			var conatcUser = await personService.GetAsync(contact.Select(x => x.Subscribers).ToList());
			conatcUser = conatcUser.Where(c => c.Id != resId).ToList();
			//  await Clients.User(reciver).SendAsync("ListContact", conatcUser.Select(x => new object[]
			//   {
			//        contact.Where(c=>c.Subscribers== x.Id).FirstOrDefault().IsSubscribers?   x.UserName : x.PhoneNumber

			//         , x.PhoneNumber ,
			//           x.Id ,
			//         "data:image/jpeg;base64,"+ Convert.ToBase64String(x.ProfileImg, 0, x.ProfileImg.Length)
			//      , messageService.GetCount_LastMessage(x.Id, resId).Result


			//      //

			//}));
		}

		public async Task ListContact(string username = "")
		{


			var _u =  username.Length > 0 ? await personService.GetByUserName(username) :
							   await GetUser();

			var contact = await contactService.GetListAsync(_u.Id);
			if (contact.Count() > 0)
			{
				var userConatctList = await personService.GetAsync(contact.Select(x => x.Subscribers).ToList());
				if (userConatctList.Count() > 0)
				{
					userConatctList = userConatctList.Where(c => c.Id != _u.Id).ToList();
					List<ListContactViewModel> listContacts = new List<ListContactViewModel>();
					foreach (var item in userConatctList)
					{
						var lastSeen = await userSeenService.GetByUserIdAsync(item.Id);
						var _messages = await messageService.LsitMessage(recid: _u.Id, SenderId: item.Id);

						var messageTextDecript = new KeyValuePair<int, string>(0, "");
						if (_messages.Count > 0)
						{

							//var _d = await messagePaaswordService.Dcript(_messages?.OrderByDescending(x => x.Time)?.FirstOrDefault());

							messageTextDecript = new KeyValuePair<int, string>(
								_messages.Where(x => x.MessageStatus != MessageStatus.read && x.ReceiverId == _u.Id)
							.Count(),
							   messagePaaswordService.Dcript(_messages.OrderByDescending(x=>x.Time).FirstOrDefault()).Result.Text
							  //_d != null ? _d.Text : string.Empty
							  );



						}

						listContacts.Add(new ListContactViewModel()
						{
							userName = item.UserName,
							phoneNumber = item.PhoneNumber,
							Count_LastMessage = messageTextDecript,

							//messageService.GetCount_LastMessage(recid: _u.Id, SenderId: item.Id).Result,
							Id = item.Id,
							isOnline = GetUserId(item.UserName) != string.Empty ? true : false,
							profileImage = "data:image/jpeg;base64," + Convert.ToBase64String(item.ProfileImg, 0, item.ProfileImg.Length),
							lastSeen =
							GetUserId(item.UserName) != string.Empty ? "آنلاین" :
							(lastSeen != null ?
							Utility.RelativeTimeCalculator.Calculate(lastSeen.LastSeen) : ""),
							Name = item.UserName
						});


					}
					await Clients.Caller.SendAsync("ListContact", listContacts);

				}
			}
		}
		public async Task sendMessageG(string username, string message, string group)
		{


			await Clients.Group(group).SendAsync(username, message);
		}

		public async Task UserProfile()
		{
			Person _person = await personService.GetByUserName(Context.User.Identity.Name.Trim().ToLower());
			if (_person != null)
			{

				await Clients.Caller.SendAsync("UserProfile", new CurrentUser()
				{
					id = _person.Id,
					name = _person.UserName.Trim(),
					number = _person.PhoneNumber,
					pic = "data:image/jpeg;base64," + Convert.ToBase64String(_person.ProfileImg, 0, _person.ProfileImg.Length)

				});
			}

		}



		private async Task<Person> GetPersonAsync()
		  => await personService.GetByUserName(Context.User.Identity.Name.Trim().ToLower());
		public async Task GetPicProfile()
		{
			var _u = await GetPersonAsync();

			var pic = new FileContentResult(_u.ProfileImg, "image/jpeg");
			await Clients.Caller.SendAsync("GetPicProfile", pic);
		}
		public async Task LsitMessage(Guid recid, Guid caller)
		{

			var user = await personService.GetAsync(recid);

			var currnetUser = await GetUser();

			//list send  message current user ....
			var _messages = await messageService.LsitMessage(recid: user.Id, SenderId: currnetUser.Id);


			//list get message current user
			var temp = await messageService.LsitMessage(recid: currnetUser.Id, SenderId: recid);


			if (temp.Count() > 0)
			{
				temp.Where(x => x.ReceiverId == currnetUser.Id && x.MessageStatus != MessageStatus.read)
					.ToList().ForEach(m =>
				{
					m.MessageStatus = MessageStatus.read;
				});
				await messageService.UpdateAsync(temp);
				_messages.AddRange(temp);


			}

			var messagDecriptList = new List<MessagDecript>();

			if (_messages.Count() > 0)
			{
				foreach (var item in _messages)
				{
					try
					{
						var messageDecriptItem = await messagePaaswordService.Dcript(item);

						if (messageDecriptItem != null)
						{
							messagDecriptList.Add(messageDecriptItem);
							//await Clients.User(GetUserId(currnetUser.UserName))
							//	.SendAsync("CheckOpenChatPrivateUser", messageDecriptItem );


						}
					}
					catch  
					{ }



				}


			}

			await Clients.User(caller.ToString()).SendAsync("LsitMessage",
				messagDecriptList.OrderBy(x => x.Time).ToList(), caller);


			var messageDecript = new KeyValuePair<int, string>(0, "");
			string txt = messagDecriptList?.OrderByDescending(x => x.Time)?.FirstOrDefault() != null ?
				messagDecriptList?.OrderByDescending(x => x.Time)?.FirstOrDefault().Text : string.Empty;
			if (temp.Count() > 0)
			{

				messageDecript =
					new KeyValuePair<int, string>( temp.Where(x => x.MessageStatus != MessageStatus.read).Count(),   txt  );

			}
			await ListContact();
			bool isContact = false;
			var contact = await contactService.GeSingleAsync(user.Id, currnetUser.Id);

			if (contact != null)
			{
				if (contact.IsSubscribers) isContact = true;
			}

			var lastSeen = await userSeenService.GetAsync(user.UserName);
			await Clients.User(caller.ToString()).SendAsync("ShowProfileOtherUser",
				new ListContactViewModel()
				{
					Id = user.Id,
					isOnline = GetUserId(user.UserName) != string.Empty ? true : false,
					lastSeen = GetUserId(user.UserName) != string.Empty ? "آنلاین" :
						(lastSeen != null ?
						Utility.RelativeTimeCalculator.Calculate(lastSeen.LastSeen) : ""),
					userName = isContact ? user.FullName : user.UserName
						,
					profileImage = "data:image/jpeg;base64," + Convert.ToBase64String(user.ProfileImg, 0, user.ProfileImg.Length)
				,
					phoneNumber = user.FullName,
					Name = user.UserName,
					Count_LastMessage = messageDecript
				}


				);
			 

		 

		}
		private async Task UpdateListMessage(List<Message> _message, MessageStatus status)
		{
			foreach (var item in _message)
			{
				item.MessageStatus = status;
			}
			await messageService.UpdateAsync(_message);
		}





		public async Task UserType(Guid userId, bool type)
		{
			var _u = await personService.GetAsync(userId);
			var currntUser = await GetUser();
			string RECIVER = _u != null ? GetUserId(_u.UserName) : string.Empty;
			if (type)
			{
				var currnetUser = await GetUser();
				// if(RECIVER!=string.Empty)
				//list send  message current user ....
				//  await UpdateListMessage(await messageService.LsitMessage(recid: userId, SenderId: currnetUser.Id), MessageStatus.delivered);

			}
			await Clients.User(RECIVER).SendAsync("UserType", currntUser.Id, type);

			// Console.WriteLine($"{RECIVER} - {_u.UserName}" );
		}

		private async Task<Person> GetUser(string username = "")
		{
			if (username.Length > 3 && string.IsNullOrWhiteSpace(username))
				return await personService.GetByUserName(username);
			return await personService.GetByUserName(Context.User.Identity.Name.Trim().ToLower());



		}
		private string UserNameCurrentUser() => Context?.User?.Identity?.Name?.Trim().ToLower();


	}
}
