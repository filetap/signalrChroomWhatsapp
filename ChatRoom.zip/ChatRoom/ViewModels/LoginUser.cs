﻿using System.ComponentModel.DataAnnotations;

namespace ChatRoom.ViewModels.Users
{
    public class LoginUser
    {

        [Display(Name = "نام کاربری")]
        
        [Required(ErrorMessage = "لطفا {0} را وارد فرمایید")]
        public string UserName { get; set; } = null!;

        //[DataType(dataType: DataType.Password)]
        [Display(Name = "رمز ورود")]
        [Required(ErrorMessage = "لطفا {0} را وارد فرمایید")]
        public string Password { get; set; }="a123456";
        //[Display(Name = "مرا به خاطر بسپار")]
        //[Required(ErrorMessage = "لطفا {0} را وارد فرمایید")]
        //public bool RememberMe { get; set; }





    }
}
