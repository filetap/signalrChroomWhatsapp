"use strict";
let chat_list = document.getElementById('chat-list');

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();
//Disable the send button until connection is established.
document.getElementById("sendButton").disabled = true;
let modalbody = document.getElementById('modalbody');
let exampleModal = document.getElementById('exampleModal');
var callBio = false;
let contactList = [];
let listMessages = [];
let groupList = [];
let user = {};
let CurrentUser = ''



connection.on("CheckOpenChatPrivateUser", function (message) {

  
    connection.invoke("CheckOpenChatPrivateUser", message, (message.senderId === CurrentUser)).then(function () { }).catch(function (err) {


        return console.error(err.toString());
    });

});


connection.on("ReceiveMessage", function (msg, check = false) {

   
        let showMessage = false
        if (msg.senderId === user.id)
            showMessage = true;

        else if (msg.senderId === CurrentUser) showMessage = true
        //to do check online user  
        if (!showMessage) { return; }
     

    var div = document.createElement("div");
    let htmlForGroup = `
	<div class="small font-weight-bold text-primary">
		${msg.senderUserName}
	</div>
	`;


    let sendStatus = ''

    switch (parseInt(msg.messageStatus)) {
        case 0:
            {
                sendStatus = `<i class="fa fa-check-circle"></i>`
                break;
            }
        case 1:
            {
                sendStatus = `<i class="fa fa-check-circle"></i>`
                    + `<i class="fa  fa-check-circle"></i>`
                break;
            }

        case 2:
            {
                sendStatus = `<i class="fas fa fa-check-circle"></i>`
                    + `<i class="fas fa fa-check-circle"></i>`
                break;
            }
    }
    msg.senderUserName === user.name ? div.classList.add('align-self-end', 'self') :
        div.classList.add('align-self-start')
    div.classList.add('my-1', 'mx-3');
    div.classList.add('rounded');
    div.classList.add('bg-white', 'shadow-sm');
    div.classList.add('message-item', 'p-1');
    div.innerHTML = `
	 
		<div class="options">
			<a href="#"><i class="fa fa-angle-down text-muted px-2"></i></a>
		</div>
		${msg.messageType == 0 ? htmlForGroup : ""}
		<div class="d-flex flex-row">
			<div class="body m-1 mr-2">${msg.text}</div>
			<div class="time ml-auto small text-right flex-shrink-0 align-self-end text-muted" style="width:75px;">
				${mDate(msg.time).getTime()}
				${(msg.senderUserName === user.name) ? sendStatus : ""}
			</div>
		</div>
	 
	`;
    document.getElementById("messages").appendChild(div);
    DOM.messages.scrollTo(0, DOM.messages.scrollHeight);
    var ms = listMessages.find(x => x.id === mgs.id && x.messageStatus !== 2 && senderId !== user.id);
    console.log(ms);



    listMessages.push(msg)

});
connection.on("ListContact", function (list) {

    DOM.chatList.innerHTML = ''
    for (var i in list) {
        //console.log(list[i])
        let div = document.createElement('div');
        div.classList.add('chat-list-item', 'd-flex')
        div.classList.add('flex-row', 'w-100')
        div.classList.add('p-2', 'border-bottom')


        let online = `<i class="fas fa fa-circle"></i>`;
        div.innerHTML = ` 
			<img src="${list[i].profileImage}" alt="Profile Photo" class="img-fluid rounded-circle mr-2" style="height:50px;width: 50px;">
			<div class="w-50">
				<div class="name" >${list[i].name}</div>
                <div class="small last-message"> ${list[i].count_LastMessage.value} 
                <i class="fa fa-check-circle mr-1" style="display:none"></i>
                
                </div>
           	</div>
			 <div class="flex-grow-1 text-right">
				<div class="small time">${list[i].lastSeen}</div>
				${list[i].count_LastMessage.key >
                0 ? "<div class=\"badge badge-success badge-pill small\" id=\"unread-count\">" + list[i].count_LastMessage.key + "</div>" : ""}
			  ${list[i].isOnline === false ? '' : online}
                
                </div>
	 
		`;

        let id = list[i].id

        div.addEventListener('click', function () {
            connection.invoke("LsitMessage", id, user.id).catch(function (err) { });
            CurrentUser = id;


        })
        DOM.chatList.append(div);
    }
    DOM.messages.scrollTo(0, DOM.messages.scrollHeight);
});
connection.on("LsitMessage", function (_messages, uid) {


    DOM.messages.innerHTML = ''

    _messages.forEach((msg) => {

        let htmlForGroup = `
	<div class="small font-weight-bold text-primary">
		${msg.senderUserName}
	</div>
	`;

        let sendStatus = `<i class="${parseInt(msg.messageStatus) < 2 ? "fa " : "fas fa"} fa-check-circle"></i>`;
        sendStatus += parseInt(msg.messageStatus) > 0 ? `<i class="${parseInt(msg.messageStatus) < 2 ? "fa" : "fas fa"} fa-check-circle"></i>` : ``;

        DOM.messages.innerHTML += `
	<div class="align-self-${msg.senderUserName === user.name ? "end self" : "start"} p-1 my-1 mx-3 rounded bg-white shadow-sm message-item">
		<div class="options">
			<a href="#"><i class="fa fa-angle-down text-muted px-2"></i></a>
		</div>
		${msg.messageType == 0 ? htmlForGroup : ""}
		<div class="d-flex flex-row">
			<div class="body m-1 mr-2">
            <div class="message-medai">   </div>    

            ${msg.text}</div>
			<div class="time ml-auto small text-right flex-shrink-0 align-self-end text-muted" style="width:75px;">
				${mDate(msg.time).getTime()}
				${(msg.senderUserName === user.name) ? sendStatus : ""}
			</div>
		</div>
	</div>
	`;


        listMessages.push(msg)
    });
    DOM.messages.scrollTo(0, DOM.messages.scrollHeight);
    mClassList(DOM.messageAreaOverlay).add("d-none");
    mClassList(DOM.inputArea).contains("d-none", (elem) => elem.remove("d-none").add("d-flex"));


});

connection.start().then(function () {
    notifyMe() 
    document.getElementById("sendButton").disabled = false;
    CurrentUser = ''
    connection.invoke("UserProfile").catch(function (err) {
        return console.error(err.toString());
    });
    //connection.invoke("ContctList").catch(function (err) {
    //    return console.error(err.toString());
    //});

    connection.invoke("ListContact", "").catch(function (err) {
        return console.error(err.toString());
    });

}).catch(function (err) {
    return console.error(err.toString());
});

function changepic(div) {
    document.getElementById(div).src = "https://upload.wikimedia.org/wikipedia/commons/1/1b/Square_200x200.png";
}

function notifyMe() { }



connection.on("UserProfile", function (result) {

    user.name = result.name;
    user.id = result.id;
    user.number = result.number;
    user.pic = result.pic

    //connection.on("ContctList", function (list) {
    //    contactList.push(list.contact)
    //    messages.push(list.message)
    //    //  init(result);
    //});

});



document.getElementById("sendButton").addEventListener("click", function (event) {
    var message = document.getElementById("input").value;
    if (message.length > 0) {
        connection.invoke("sendMessage", CurrentUser, message).catch(function (err) {
            return console.error(err.toString());
        });
        document.getElementById("input").value = ''
        event.preventDefault();
        document.getElementById('typeMeeage').innerHTML = "";

    }

});


document.getElementById("input").addEventListener("keydown", function (event) {
    if (event.keyCode !== 13) {

        connection.invoke("UserType", CurrentUser, true).then(function () { }).catch(function (err) {
            return console.error(err.toString());
        });
    }
    else {
        var message = document.getElementById("input").value;
        if (message.length > 0) {
            connection.invoke("sendMessage", CurrentUser, message).catch(function (err) {
                return console.error(err.toString());
            });
            document.getElementById("input").value = ''
            event.preventDefault();
            document.getElementById('typeMeeage').innerHTML = "";

        }

    }

});
connection.on("UserType", function (res, type) {

    if (res === CurrentUser && type == true) {
        document.getElementById('typeMeeage').innerHTML = "در حال نوشتن ...";
    }
    else {
        document.getElementById('typeMeeage').innerHTML = "";
    }


});





document.getElementById('openListContact').addEventListener('click', function () {

});

connection.on("ShowProfileOtherUser", function (result) {

    DOM.messageAreaPic.src = result.profileImage
    DOM.messageAreaName.innerHTML = result.name
    DOM.messageAreaDetails.innerHTML = result.lastSeen;
    if (!callBio) {
        //setBio();
        callBio = true
    }
});

document.getElementById('input').addEventListener('mouseout', function () {
    connection.invoke("UserType", CurrentUser, false).catch(function (err) {
        return console.error(err.toString());
    });

})


//config contact  - create element , ...


let getById = (id, parent) => parent ? parent.getElementById(id) : getById(id, document);
let getByClass = (className, parent) => parent ? parent.getElementsByClassName(className) : getByClass(className, document);

const DOM = {
    chatListArea: getById("chat-list-area"),
    messageArea: getById("message-area"),
    inputArea: getById("input-area"),
    chatList: getById("chat-list"),
    messages: getById("messages"),
    chatListItem: getByClass("chat-list-item"),
    messageAreaName: getById("name", this.messageArea),
    messageAreaPic: getById("pic", this.messageArea),
    messageAreaNavbar: getById("navbar", this.messageArea),
    messageAreaDetails: getById("details", this.messageAreaNavbar),
    messageAreaOverlay: getByClass("overlay", this.messageArea)[0],
    messageInput: getById("input"),
    profileSettings: getById("profile-settings"),
    profilePic: getById("profile-pic"),
    profilePicInput: getById("profile-pic-input"),
    inputName: getById("input-name"),
    username: getById("username"),
    displayPic: getById("display-pic"),
    typeMessage: getById("typeMessage"),
};

let mClassList = (element) => {
    return {
        add: (className) => {
            element.classList.add(className);
            return mClassList(element);
        },
        remove: (className) => {
            element.classList.remove(className);
            return mClassList(element);
        },
        contains: (className, callback) => {
            if (element.classList.contains(className))
                callback(mClassList(element));
        }
    };
};

// 'areaSwapped' is used to keep track of the swapping
// of the main area between chatListArea and messageArea
// in mobile-view
let areaSwapped = false;

// 'chat' is used to store the current chat
// which is being opened in the message area
let chat = null;

// this will contain all the chats that is to be viewed
// in the chatListArea
let chatList = [];

// this will be used to store the date of the last message
// in the message area
let lastDate = "";

// 'populateChatList' will generate the chat list
// based on the 'messages' in the datastore



let showChatList = () => {
    if (areaSwapped) {
        mClassList(DOM.chatListArea).remove("d-none").add("d-flex");
        mClassList(DOM.messageArea).remove("d-flex").add("d-none");
        areaSwapped = false;
    }
};



let showProfileSettings = () => {
    DOM.profileSettings.style.left = 0;
    DOM.profilePic.src = user.pic;
    DOM.inputName.value = user.name;
};

let hideProfileSettings = () => {
    DOM.profileSettings.style.left = "-110%";
    //  DOM.username.innerHTML = user.name;
};

window.addEventListener("resize", e => {
    if (window.innerWidth > 575) showChatList();
});

function init(user) {
    console.log(user)
    DOM.username.innerHTML = user.name;
    //DOM.displayPic.src = user.pic;
    //DOM.profilePic.stc = user.pic;
    DOM.profilePic.addEventListener("click", () => DOM.profilePicInput.click());
    DOM.profilePicInput.addEventListener("change", () => console.log(DOM.profilePicInput.files[0]));
    DOM.inputName.addEventListener("blur", (e) => user.name = e.target.value);
    generateChatList();

    /*	console.log("Click the Image at top-left to open settings.");*/
};



//datastory





// message status - 0:sent, 1:delivered, 2:read


