var emojiButton = document.getElementById('emoji'); 
 
emojiButton.addEventListener('click', function (event) {


    fetch(`/js/emoji.json`, {
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

    }).then((response) => {
       var data= response.json()
        console.log(data)
    })
        .then((messages) => { console.log("messages"); })
        .catch((error) => console.log(error));


    
    
})


 