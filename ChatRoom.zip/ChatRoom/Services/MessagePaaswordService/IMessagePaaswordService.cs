﻿using ChatRoom.Models;
using ChatRoom.Models.MessageContext;
using ChatRoom.ViewModels;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System.Drawing.Printing;
using System.Reflection;

namespace ChatRoom.Services.MessagePaaswordService
{
	public interface IMessagePaaswordService
	{

		public Task<byte[]> Encript(MessageEncriptViewModel message);
		public Task<MessagDecript?> Dcript(Message model);
		public Task<List<MessagePaasword>?> GetAsync();
		public Task<List<MessagePaasword>?> GetAsync(Guid u1, Guid u2);
		public Task CreateAsync(MessagePaasword model);
		public Task CreateAsync(List<MessagePaasword> models);
		public Task UpdateAsync(Guid id, MessagePaasword updateModel);
		public Task UpdateAsync(List<MessagePaasword> updateModel);
		public Task RemoveAsync(Guid id);
		public Task RemoveAsync(List<Guid> id);
	}
	public class MessagePaaswordService : IMessagePaaswordService
	{
		public IMongoCollection<MessagePaasword> _collection;
		public MessagePaaswordService(
			IOptions<MessageDbContext> mongoDatabaseSettings)
		{
			var mongoClient = new MongoClient(
				mongoDatabaseSettings.Value.ConnectionString);

			var mongoDatabase = mongoClient.GetDatabase(
				mongoDatabaseSettings.Value.Name);
			_collection = mongoDatabase.GetCollection<MessagePaasword>(mongoDatabaseSettings.Value.MessagePaaswordCollectionName);

		}
		public static int counter { get; set; } = 0;
		public async Task<List<MessagePaasword>?> GetAsync() =>
				  await _collection
						.Find(_ => true).ToListAsync();
		public async Task<List<MessagePaasword>?> GetAsync(Guid u1, Guid u2) =>
				  await _collection
						.Find(x => (x.User1 == u1 && x.User2 == u2)
								|| (x.User2 == u1 && x.User1 == u2)
							 ).ToListAsync();
		public async Task<byte[]?> Encript(MessageEncriptViewModel message)
		{
			var KeyMessage = await FindKeyMessage(message.sender, message.recvId, message.Time);
			Console.WriteLine($"keyMeeage: {KeyMessage != null} - time :  {message.Time}");
			if (KeyMessage != null)
				return Utility.AesEncryption.Encrypt(message.body, KeyMessage.Key, KeyMessage.Iv);
			return null;



		}
		private async Task<MessagePaasword?> FindKeyMessage(Guid user1, Guid user2, DateTime time)
		{
			var model = await GetAsync(user1, user2);
			var lastKey = new MessagePaasword();

			if (model.Count()>0)
			{
				lastKey = model.OrderByDescending(x => x.To).FirstOrDefault();
				if (time.Kind > lastKey.To.Kind)
					return await newMessagePaasword(user1, user2);
				else return lastKey;

			}


			else
				return await newMessagePaasword(user1, user2);



		}


		public async Task<MessagDecript?> Dcript(Message item)
		{

			var KeyMessage = await FindKeyMessage(item.SenderId, item.ReceiverId, item.Time);

			if (KeyMessage != null)
			{
				Utility.AesEncryption.Decrypt(item.Text, KeyMessage.Key, KeyMessage.Iv, out string decMessage);
				if (decMessage != string.Empty)
				{
					return new MessagDecript()
					{
						Id = item.Id,
						MessageStatus = item.MessageStatus,
						MessageType = item.MessageType,
						ReceiverId = item.ReceiverId,
						ReceiverUserName = item.ReceiverUserName,
						SenderId = item.SenderId,
						SenderUserName = item.SenderUserName,
						Text = decMessage,
						Time = item.Time,
						PersionTime = Utility.RelativeTimeCalculator.Calculate(item.Time)
					};
				}



			}
			return null;
		}


		private async Task<MessagePaasword> newMessagePaasword(Guid user1, Guid user2)
		{
			var conf = Utility.AesEncryption.ConfigEncriptor();
			var mp = new MessagePaasword();
			mp.Id = Guid.NewGuid();
			mp.Key = conf.Key;
			mp.Iv = conf.Value;
			mp.User1 = user1;
			mp.User2 = user2;
			mp.From = Utility.RelativeTimeCalculator.SetKind(DateTime.Now, DateTimeKind.Local);
			mp.To = Utility.RelativeTimeCalculator.SetKind(DateTime.Now.AddSeconds(1), DateTimeKind.Local);
			await CreateAsync(mp);
			return mp;
		}

		public async Task CreateAsync(MessagePaasword model) =>
		 await _collection.InsertOneAsync(model);
		public async Task CreateAsync(List<MessagePaasword> models) =>
		await _collection.InsertManyAsync(models);
		public async Task UpdateAsync(Guid id, MessagePaasword updateModel) { }
		public async Task UpdateAsync(List<MessagePaasword> updateModel) { }
		public async Task RemoveAsync(Guid id) { }
		public async Task RemoveAsync(List<Guid> id) { }
	}



}
