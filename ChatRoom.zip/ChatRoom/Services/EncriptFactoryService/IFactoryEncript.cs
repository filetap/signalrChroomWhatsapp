﻿namespace ChatRoom.Services.EncriptFactoryService
{
	public interface IFactoryEncript
	{
		 

	}
}
