﻿using ChatRoom.Models;
using ChatRoom.Services.FileConverter;
using ChatRoom.Services.PersonService;
using ChatRoom.Services.PhoneNumberGeneratorService;
using ChatRoom.ViewModels.Users;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Win32;
using System.ComponentModel.DataAnnotations;



namespace Zpanel.Controllers
{
    public class AccountController : Controller
    {
        private UserManager<Person> userManager;
        private SignInManager<Person> signInManager;
        private readonly IPersonService _currentUser;
        private readonly IFileConverterService fileConverterService;
        private readonly IWebHostEnvironment env;
        public AccountController(UserManager<Person> userManager, SignInManager<Person> signInManager, IPersonService currentUser, IFileConverterService fileConverterService, IWebHostEnvironment env)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            _currentUser = currentUser;
            this.fileConverterService = fileConverterService;
            this.env = env;
        }

        [Route("Login")]
        public IActionResult Login()
        {
            return View();
        }
        [Route("Login")]
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        // public async Task<IActionResult> Login([Required][EmailAddress] string email, [Required] string password, string returnurl)
        public async Task<IActionResult> Login(LoginUser loginUser)
        {
            if (ModelState.IsValid)
            {
                Person appUser = await userManager.FindByNameAsync(loginUser.UserName);
                if (appUser != null)
                {
                    Microsoft.AspNetCore.Identity.SignInResult result =
                        await signInManager.PasswordSignInAsync(appUser, loginUser.Password, false, false);
                    if (result.Succeeded)
                    {
                        return Redirect("/Home/Index");
                    }

                    else
                    {
                        return Json(new { result });
                    }
                }
                ModelState.AddModelError(nameof(loginUser.UserName), "خطا در ورود!!!!!");
                return View();

            }
            return View();


        }
        public IActionResult Create() => View();
        [HttpPost]
        public async Task<IActionResult> Create(RegisterUser register)
        {
            if (ModelState.IsValid)
            {
                //  _roleManager.CreateAsync(new ApplicationRole() { Name = "admin" });

                var uu = await _currentUser.GetByUserName(register.UserName);
                if (uu != null)
                {
                    return Json(new
                    {
                        Message = "نام کاربری وارد شده تکراری می باشد",
                        StatusCode = 402
                    });
                }

                byte[] pic = null;
                if (register.ProfileImg != null)
                {

                    pic = await fileConverterService.Convert(register.ProfileImg);
                }
                var _p = new Person()
                {
                    Status = true,
                    PhoneNumber = register.PhoneNumber,
                    EmailConfirmed = true,
                    PhoneNumberConfirmed = true,

                    DateCreate = DateTime.Now,
                    UserName = register.UserName,
                    ProfileImg = pic ,
                    FullName= register.Name, 
                    Bio= register.Bio,
                    // Roles = _roleManager.Roles.Select(x => x.Id).ToList()
                };

                //_p.AddRole()

                var resUser = await userManager.CreateAsync(_p, register.Password);

                if (!resUser.Succeeded)
                {
                    string xx = string.Empty;
                    resUser.Errors.ToList().ForEach(x =>
                    {
                        xx += $"{x.Description}- {x.Code}{Environment.NewLine}";
                    });
                    return Json(

                        new { xx }
                        );
                }


                var findUser = await _currentUser.GetByUserName(register.UserName);

                if (findUser == null)
                {
                    return Content("user not found !!!!!");
                }




                return Json(new
                {
                    UserName = register.UserName,
                    Password = register.Password
                });
            }

            return View(register);
        }

        public async Task<IActionResult> newUser()
        {
           List<string> u= new List<string> ();
            for (int i = 1; i < 13; i++)
            {
               
                byte[] profByte = System.IO.File.ReadAllBytes(env.WebRootPath + $"/images/{i}.jpg");
                try
                {
                    string UserName = UserNameGenerator.GenerateRandomUserName();
                    var uu = await _currentUser.GetByUserName(UserName);
                    if (uu == null)
                    {
                        var _p = new Person()
                        {
                            Status = true,
                            PhoneNumber = PhoneNumberGenerator.GenerateRandomPhoneNumber(),
                            EmailConfirmed = true,
                            PhoneNumberConfirmed = true,

                            DateCreate = DateTime.Now,
                            UserName = UserName,
                            ProfileImg = profByte
                            // Roles = _roleManager.Roles.Select(x => x.Id).ToList() , 
                            , Bio= "this is test message" ,
                            FullName = Utility.RandomKey.RandomCharacters(5),
                        };

                        var result = await userManager.CreateAsync(_p, "a123456");
                        if (result.Succeeded)
                        {
                            u.Add(UserName);
                        }
                        
                        Console.Write(result.Succeeded);
                    }
                    else
                    {
                        Console.Write("user is exists ...");
                    }
                }
                catch  (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                 
            }
             
             

           
            return Json(new
            {
              u= u
            });
        }


        [Authorize]
        //[HttpPost("Logout")]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }

    }
}
